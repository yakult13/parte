<?php

	include_once 'config/dbconnection.php';
 
 
 //server 
$sql = "SELECT * FROM server WHERE Status ='active'";
$connStatus = $conn->query($sql);
$server = mysqli_num_rows($connStatus);
 
$sqlz = "SELECT * FROM server";
$connStatusz = $conn->query($sqlz);
$serverz = mysqli_num_rows($connStatusz);

$sqls = "SELECT * FROM server WHERE Status ='down'";
$connStatuss = $conn->query($sqls);
$servers = mysqli_num_rows($connStatuss);

//l2tp servers

$sqla = "SELECT * FROM L2TP WHERE status ='active'";
$connStatusza = $conn->query($sqla);
$servera = mysqli_num_rows($connStatusza);
 
$sqlzz = "SELECT * FROM L2TP";
$connStatuszz = $conn->query($sqlzz);
$serverzz = mysqli_num_rows($connStatuszz);

$sqlss = "SELECT * FROM L2TP WHERE status ='down'";
$connStatussz = $conn->query($sqlss);
$serversz = mysqli_num_rows($connStatussz);

//users free
$sqluseractive = "SELECT * FROM users where status = 1 AND type = 'free'";
$connusersactive = $conn->query($sqluseractive);
$useractive = mysqli_num_rows($connusersactive);
 
$sqlusersexpired = "SELECT * FROM users where status = 0 AND type = 'free'";
$connuserexpired = $conn->query($sqlusersexpired);
$usersexpired = mysqli_num_rows($connuserexpired);


//user vip
$sqluseractivez = "SELECT * FROM users where status = 1 AND type = 'vip'";
$connusersactivez = $conn->query($sqluseractivez);
$useractivez = mysqli_num_rows($connusersactivez);

$sqlusersexpiredz = "SELECT * FROM users where status = 0 AND type = 'vip'";
$connuserexpiredz = $conn->query($sqlusersexpiredz);
$usersexpiredz = mysqli_num_rows($connuserexpiredz);

//l2tp
$sqluseractives = "SELECT * FROM users where status = 1 AND type = 'L2TP'";
$connusersactives = $conn->query($sqluseractives);
$useractives = mysqli_num_rows($connusersactives);

$sqlusersexpires = "SELECT * FROM users where status = 0 AND type = 'L2TP'";
$connuserexpires = $conn->query($sqlusersexpires);
$usersexpires = mysqli_num_rows($connuserexpires);

$sqluserss = "SELECT * FROM users where type = 'L2TP'";
$connusers = $conn->query($sqluserss);
$userss = mysqli_num_rows($connusers);

//total users
$sqlusers = "SELECT * FROM users where userid >= '1'";
$connuser = $conn->query($sqlusers);
$users = mysqli_num_rows($connuser);

//total actives
$total_server = $serverz;
$total_user  = $users + $userss;
$total_active = $useractive + $useractives + $useractivez;
$total_server_active = $server;

//total expired users
$total_expired = $usersexpired + $usersexpires + $usersexpiredz;

//total vip accounts
$totalvip_account = $useractivez + $usersexpiredz;

//free panel stats
$panelexpired = $usersexpired + $usersexpires;
$panelactives = $useractive + $useractives;


//downloads
$time = time();

$online = "SELECT * FROM members where lastAction > $time";
$connonline = $conn->query($online);
$users_online = mysqli_num_rows($connonline);

$offline = "SELECT * FROM members where lastAction < $time";
$connoffline = $conn->query($offline);
$users_offline = mysqli_num_rows($connoffline);

$total = "SELECT * FROM members";
$conntotal = $conn->query($total);
$total_users = mysqli_num_rows($conntotal);
?>