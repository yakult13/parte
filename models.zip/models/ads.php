<?php
session_start();
include 'auth.php';

 include 'connectcfg.php';
$sql = "SELECT * FROM addmanager ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$adsid =  $row["adsid"];
        $status =  $row["status"];
	    
	}
} else {
    echo "0 results";
}	



?>