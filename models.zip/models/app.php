<?php 
include_once '../config/dbconnection.php';

if(isset($_GET['app_id'])){
    $app = $_GET['app_id'];

    $sql = "SELECT * FROM downloads WHERE id = ".$app."";
$results = $conn->query($sql);
$count=0;
if ($results->num_rows > 0) {
    // output data of each row
    while($row = $results->fetch_assoc()) {
		$ids =  $row["id"];
        $downloads =  $row["downloads"];
    }
}
    $query = "UPDATE downloads SET downloads = '$downloads' + 1 WHERE id = ".$ids."";
    $result = mysqli_query($conn, $query);
    if($result){
        header('location: /downloads/app_update_5.0.0.apk');

}
    
}
    $conn->close();