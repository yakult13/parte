 <?php
include 'config/dbconnection.php';
$sql = "SELECT * FROM server";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$serverid =  $row["serverid"];
		$host =  $row["host"];
	    $hostname =  $row["hostname"];
		
		
		$logname = 'openvpn-status';	
		
    $file = 'http://'.$host.'/'.$logname.'.log';
$newfile = 'userconnected/'.$hostname.'';

if (copy($file, $newfile) ) {
  echo '';
}else{
    echo "";
}
	
	
	
	
	}
} else {
    echo "0 results";
}
	  
	  ?>

