<?php

$serverPort = '22';
$serverUser = 'root';
$serverPassword = 'juansvpn';
$file = 'chmodopenvpn.php';


  include '../config/dbconnection.php';
$sql = "SELECT * FROM server";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$serverid =  $row["serverid"];
		$host =  $row["host"];
	    $hostname =  $row["hostname"];
		
	$connection = ssh2_connect($host, $serverPort);

if(ssh2_auth_password($connection, $serverUser, $serverPassword)){
    echo "connected\n";
    ssh2_scp_send($connection, "/var/www/html/models/".$file, "/var/www/html/models".$file);
    echo "done\n";
} else {
    echo "connection failed\n";
}
	
	
	
	
	}
} else {
    echo "0 results";
}





?>


