


 <?php
  include '../config/dbconnection.php';
$sql = "SELECT * FROM server";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$serverid =  $row["serverid"];
		$host =  $row["host"];
	    $hostname =  $row["hostname"];
		
		
	
	if( $curl = curl_init() ) {
 curl_setopt($curl, CURLOPT_URL, 'http://'.$host.'/chmodopenvpn.php');
curl_setopt($curl, CURLOPT_TIMEOUT, 1);
  curl_exec($curl);      
  curl_close($curl);


}

 exec("wget"."http://'.$host.'/chmodopenvpn.php");

	
	
	
	}
} else {
    echo "0 results";
}
	  
	  ?>



