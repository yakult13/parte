<?php

include '../config/dbconnection.php';
$sql = "SELECT * FROM server";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		$serverid =  $row["serverid"];
        $host =  $row["host"];
	    $rootpass =  $row["rootpass"];



$connection_string = ssh2_connect($host, 22);

if (@ssh2_auth_password($connection_string, 'root', $rootpass))
{
	echo "Authentication Successful!\n";
}
else
{
	throw new Exception("Authentication failed!");
}

$stream = ssh2_exec($connection_string, 'delexpired');
stream_set_blocking($stream, true);
$stream_out = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
echo stream_get_contents($stream_out);


	

}
} else {
    echo "0 results";
}
?>	





