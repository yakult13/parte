
<?php

	include_once 'config/dbconnection.php';

date_default_timezone_set('UTC');
date_default_timezone_set("Asia/Manila"); 
$my_date = date("m/d/y H:i:s");



$sqls = "SELECT * FROM users";
$result = $conn->query($sqls);


if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
     
	  $dateexpired = $row["dateexpired"];
	   $user = $row["username"];



$sql = "UPDATE users SET status = '0'  where STR_TO_DATE(dateexpired, '%m/%d/%y %H:%i:%s') <= NOW('m/d/y H:i:s')" ;


}

if ($conn->query($sql) === TRUE) {

} else {
    
}
}

?>