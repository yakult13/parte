<?php

if(isset($_GET['id'])) {
    $downid = $_GET['id'];

    include '../config/dbconnection.php';

    $sql = "SELECT * FROM upload_configs WHERE id = '$downid'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $id = $row["id"];
            $typez = $row["type"];
            $val = $row["validity"];
            $confz = $row["configs"];
            $downloads = $row["downloads"];


$fileName = basename("$confz");
$filePath = '../admin/uploads/'.$typez.'/'.$fileName;
if(!empty($fileName) && file_exists($filePath)){

    $sqla = "UPDATE upload_configs SET downloads = '$downloads' + '1' WHERE id = '$id'";
    $resultx = mysqli_query($conn, $sqla);
    if($resultx){
        header('Location: /admin/uploads/'.$typez.'/'.$confz.'');
    }
}else{
    echo 'The file does not exist.';
}
}
}
}
?>